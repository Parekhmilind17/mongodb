// module.exports.setFlash = (req,res)=>{
//         res.locals.flash={

//             "success" : req.flash("success")
//         }

//         next()
//     }